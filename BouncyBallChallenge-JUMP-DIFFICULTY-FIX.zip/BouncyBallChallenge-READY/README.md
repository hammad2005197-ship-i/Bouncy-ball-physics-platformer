# Bouncy Ball Challenge — Unity 6.3 LTS

A single long 3D physics platformer built with Unity primitives and beginner-friendly C# scripts.

## Open on Lexar SSD
1. Quit Unity.
2. Extract this ZIP into `/Volumes/Lexar/unity/Projects/`.
3. In Unity Hub choose **Add > Add project from disk** and select the extracted `BouncyBallChallenge-READY` folder (the folder containing `Assets`, `Packages`, and `ProjectSettings`).
4. Open `Assets/Scenes/BouncyBallChallenge.unity` and press Play. The track is built when Play starts; the editor helper shows a non-gameplay preview in Scene view.

## Controls
- Move: WASD or Arrow Keys (choose in Settings).
- Jump: Space.
- Pause/resume: Escape or Pause button.

## Difficulty
There is one long track. Easy uses wider platforms, smaller gaps, fewer/slower hazards, and a stronger jump. Normal is balanced. Hard uses narrower platforms, larger gaps, more hazards, and faster hazards. Select a difficulty before pressing Start Game.

## Physics and audio
- The ball has a Rigidbody and an actual `Assets/Resources/BallPhysics.physicMaterial` asset. Platforms and rails use `Assets/Resources/PlatformPhysics.physicMaterial`. The editor helper creates these assets on first project import; runtime fallback materials are used if needed.
- Background music is generated as a looping melodic audio clip. Jump, coin, hazard, win, and fall sound effects are generated in code. Ensure the Game view is running and the Mac/Unity audio is not muted.

## Learning concepts
- `GameManager.cs`: Rigidbody movement, jump, raycast grounding, difficulty, generated track, UI, audio, and game states.
- `CollectibleCoin.cs`: trigger, Player tag, score, animation, and `Destroy()`.
- `RotatingHazard.cs`: rotation, collision, sound, and fail state.
- `FinishZone.cs`: trigger and win state.
- `EditorScenePreview.cs`: editor-only Scene view preview.

This project uses built-in Unity modules and requires no external assets. The ZIP structure was checked, but this environment cannot run Unity Editor, so compile/gameplay verification must still be done in Unity.
