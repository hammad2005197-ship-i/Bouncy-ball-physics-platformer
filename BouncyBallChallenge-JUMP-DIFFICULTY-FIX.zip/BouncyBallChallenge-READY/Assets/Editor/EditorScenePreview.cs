#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

[InitializeOnLoad]
public static class EditorScenePreview
{
    static GameObject previewRoot;
    static EditorScenePreview()
    {
        EditorApplication.delayCall += EnsurePhysicsMaterialAssets;
        EditorApplication.delayCall += Refresh;
        EditorSceneManager.sceneOpened += OnSceneOpened;
        EditorApplication.playModeStateChanged += OnPlayModeChanged;
    }
    static void OnSceneOpened(Scene scene, OpenSceneMode mode) { EditorApplication.delayCall += Refresh; }
    static void OnPlayModeChanged(PlayModeStateChange state)
    {
        if (state == PlayModeStateChange.ExitingEditMode || state == PlayModeStateChange.EnteredPlayMode) ClearPreview();
        if (state == PlayModeStateChange.EnteredEditMode) EditorApplication.delayCall += Refresh;
    }
    static void ClearPreview()
    {
        if (previewRoot != null) Object.DestroyImmediate(previewRoot);
        previewRoot = null;
        GameObject existing = GameObject.Find("EDITOR PREVIEW - auto generated");
        if (existing != null) Object.DestroyImmediate(existing);
    }
    static void EnsurePhysicsMaterialAssets()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Resources")) AssetDatabase.CreateFolder("Assets", "Resources");
        CreatePhysicsAsset("Assets/Resources/BallPhysics.physicMaterial", true);
        CreatePhysicsAsset("Assets/Resources/PlatformPhysics.physicMaterial", false);
        AssetDatabase.SaveAssets();
    }
    static void CreatePhysicsAsset(string path, bool isBall)
    {
        PhysicMaterial material = AssetDatabase.LoadAssetAtPath<PhysicMaterial>(path);
        if (material == null)
        {
            material = new PhysicMaterial(isBall ? "BallPhysics" : "PlatformPhysics");
            AssetDatabase.CreateAsset(material, path);
        }
        material.dynamicFriction = isBall ? 0.42f : 0.68f;
        material.staticFriction = isBall ? 0.55f : 0.78f;
        material.bounciness = isBall ? 0.08f : 0.02f;
        material.frictionCombine = isBall ? PhysicMaterialCombine.Average : PhysicMaterialCombine.Maximum;
        material.bounceCombine = PhysicMaterialCombine.Minimum;
        EditorUtility.SetDirty(material);
    }
    static void Refresh()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        if (Object.FindObjectOfType<GameManager>() == null) return;
        ClearPreview();
        previewRoot = new GameObject("EDITOR PREVIEW - auto generated");
        previewRoot.hideFlags = HideFlags.DontSaveInEditor | HideFlags.DontSaveInBuild;
        Material blue = Mat(new Color(0.08f, 0.29f, 0.55f));
        Material purple = Mat(new Color(0.32f, 0.13f, 0.62f));
        Material red = Mat(new Color(0.9f, 0.06f, 0.13f));
        Material gold = Mat(new Color(1f, 0.72f, 0.03f));
        Material cyan = Mat(new Color(0.03f, 0.85f, 1f));
        for (int i = 0; i < 12; i++)
        {
            float z = i == 0 ? 0f : 10f + (i - 1) * 8.4f;
            float length = i == 0 ? 11f : 7.5f;
            float x = Mathf.Sin(i * 0.62f) * 0.65f;
            Cube("Preview Platform " + (i + 1), new Vector3(x, 0f, z + length * 0.5f), new Vector3(8f, 0.75f, length), i % 2 == 0 ? blue : purple);
            Cube("Preview Left Rail", new Vector3(x - 3.92f, 0.5f, z + length * 0.5f), new Vector3(0.24f, 1.15f, length + 0.6f), red);
            Cube("Preview Right Rail", new Vector3(x + 3.92f, 0.5f, z + length * 0.5f), new Vector3(0.24f, 1.15f, length + 0.6f), red);
            if (i > 0 && i % 2 == 1) Cube("Preview Hazard", new Vector3(x, 0.9f, z + length * 0.55f), new Vector3(5.3f, 0.3f, 0.42f), red);
            for (int c = 0; c < 2; c++)
            {
                GameObject coin = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                coin.name = "Preview Collectible"; coin.transform.SetParent(previewRoot.transform);
                coin.transform.position = new Vector3(x + (c == 0 ? -1.1f : 1.1f), 1.35f, z + 2.2f + c * 3.1f);
                coin.transform.localScale = Vector3.one * 0.48f; coin.GetComponent<Renderer>().sharedMaterial = gold;
                Collider col = coin.GetComponent<Collider>(); if (col != null) Object.DestroyImmediate(col);
            }
        }
        GameObject ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ball.name = "Preview Player Ball"; ball.transform.SetParent(previewRoot.transform); ball.transform.position = new Vector3(0f, 0.82f, 0f); ball.transform.localScale = Vector3.one * 0.82f; ball.GetComponent<Renderer>().sharedMaterial = cyan;
        Collider ballCollider = ball.GetComponent<Collider>(); if (ballCollider != null) Object.DestroyImmediate(ballCollider);
        SceneView view = SceneView.lastActiveSceneView;
        if (view != null) { view.pivot = new Vector3(0f, 0f, 26f); view.size = 55f; view.rotation = Quaternion.Euler(25f, 0f, 0f); view.Repaint(); }
    }
    static Material Mat(Color color)
    {
        Shader shader = Shader.Find("Standard");
        Material m = new Material(shader); m.color = color; m.hideFlags = HideFlags.HideAndDontSave; return m;
    }
    static void Cube(string name, Vector3 pos, Vector3 scale, Material mat)
    {
        GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube); obj.name = name; obj.transform.SetParent(previewRoot.transform); obj.transform.position = pos; obj.transform.localScale = scale; obj.GetComponent<Renderer>().sharedMaterial = mat;
        Collider col = obj.GetComponent<Collider>(); if (col != null) Object.DestroyImmediate(col);
    }
}
#endif
