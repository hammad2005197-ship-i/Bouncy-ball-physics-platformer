using UnityEngine;
public class CollectibleCoin : MonoBehaviour
{
    Vector3 startPosition;
    void Start() { startPosition = transform.position; }
    void Update() { transform.Rotate(0f, 105f * Time.deltaTime, 0f, Space.World); transform.position = startPosition + Vector3.up * (Mathf.Sin(Time.time * 3f + startPosition.z) * 0.12f); }
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) { if (GameManager.Instance != null) GameManager.Instance.CollectCoin(); Destroy(gameObject); }
    }
}
