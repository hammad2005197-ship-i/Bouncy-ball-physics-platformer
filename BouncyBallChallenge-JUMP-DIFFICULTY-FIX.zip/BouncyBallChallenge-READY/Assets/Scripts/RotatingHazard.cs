using UnityEngine;
public class RotatingHazard : MonoBehaviour
{
    public float speed = 60f;
    bool played;
    void Update() { transform.Rotate(0f, speed * Time.deltaTime, 0f, Space.World); }
    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.CompareTag("Player") && GameManager.Instance != null)
        {
            if (!played) { GameManager.Instance.PlayHazardSound(); played = true; }
            GameManager.Instance.FailLevel();
        }
    }
}
