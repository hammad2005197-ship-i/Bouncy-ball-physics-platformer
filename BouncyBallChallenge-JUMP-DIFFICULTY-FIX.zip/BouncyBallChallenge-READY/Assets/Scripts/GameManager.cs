using UnityEngine;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public enum GameState { Menu, Settings, Playing, Paused, Won, Failed }
    public static GameManager Instance;
    public GameState State = GameState.Menu;
    public int selectedLevel = 1; // 1-3
    public int difficulty = 1; // 0 easy, 1 normal, 2 hard
    public bool useArrowKeys = false;
    public bool soundEnabled = true;
    public float musicVolume = 0.34f;
    public int score;
    public int coinTotal;
    public Transform player;
    public Rigidbody playerBody;
    public Camera gameCamera;
    Transform levelRoot;
    Vector3 spawnPoint;
    float finishZ;
    float moveSpeed = 8f;
    float jumpForce = 7.5f;
    float cameraDistance = 9f;
    AudioSource musicSource, sfxSource;
    AudioClip jumpClip, coinClip, hitClip, winClip, failClip;
    PhysicMaterial ballPhysicsMaterial, platformPhysicsMaterial;
    float jumpCooldown;
    GUIStyle titleStyle, subtitleStyle, buttonStyle, hudStyle, smallStyle, panelStyle;
    Material blue, blueLight, purple, red, gold, cyan, dark, white, green, orange;
    bool stylesReady;

    void Awake() { Instance = this; }
    void Start()
    {
        Application.targetFrameRate = 60;
        MakeMaterials();
        SetupCameraAndLight();
        SetupPhysicsMaterials();
        SetupMusic();
        BuildLevel(true);
        State = GameState.Menu;
    }

    void Update()
    {
        if (musicSource != null) { musicSource.volume = soundEnabled ? musicVolume : 0f; }
        if (sfxSource != null) sfxSource.volume = soundEnabled ? 0.85f : 0f;
        if (State == GameState.Playing && playerBody != null)
        {
            if (Input.GetKeyDown(KeyCode.Escape)) { State = GameState.Paused; return; }
            float x = 0f, z = 0f;
            if (useArrowKeys)
            {
                x = (Input.GetKey(KeyCode.RightArrow) ? 1f : 0f) - (Input.GetKey(KeyCode.LeftArrow) ? 1f : 0f);
                z = (Input.GetKey(KeyCode.UpArrow) ? 1f : 0f) - (Input.GetKey(KeyCode.DownArrow) ? 1f : 0f);
            }
            else
            {
                x = (Input.GetKey(KeyCode.D) ? 1f : 0f) - (Input.GetKey(KeyCode.A) ? 1f : 0f);
                z = (Input.GetKey(KeyCode.W) ? 1f : 0f) - (Input.GetKey(KeyCode.S) ? 1f : 0f);
            }
            Vector3 direction = new Vector3(x, 0f, z).normalized;
            playerBody.AddForce(direction * moveSpeed * 2.0f, ForceMode.Acceleration);
            Vector3 velocity = playerBody.linearVelocity;
            Vector3 horizontal = new Vector3(velocity.x, 0f, velocity.z);
            if (horizontal.magnitude > moveSpeed)
            {
                horizontal = horizontal.normalized * moveSpeed;
                playerBody.linearVelocity = new Vector3(horizontal.x, velocity.y, horizontal.z);
            }
            if (Input.GetKeyDown(KeyCode.Space) && IsGrounded() && Time.time >= jumpCooldown)
            {
                playerBody.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
                jumpCooldown = Time.time + 0.18f;
                PlaySound(jumpClip);
            }
            if (player.position.y < -5f || player.position.z < -6f) FailLevel();
        }
        if (player != null && gameCamera != null)
        {
            Vector3 target = player.position + new Vector3(0f, 6.2f, -cameraDistance);
            gameCamera.transform.position = Vector3.Lerp(gameCamera.transform.position, target, Time.deltaTime * 4.5f);
            gameCamera.transform.LookAt(player.position + Vector3.up * 0.45f);
        }
    }

    bool IsGrounded()
    {
        if (player == null || playerBody == null) return false;

        // A short sphere cast is more reliable than a single ray for a rolling sphere.
        // Ignore the player's own collider and trigger-only objects.
        Vector3 origin = player.position + Vector3.up * 0.08f;
        RaycastHit[] hits = Physics.SphereCastAll(origin, 0.24f, Vector3.down, 0.68f, ~0, QueryTriggerInteraction.Ignore);
        foreach (RaycastHit hit in hits)
        {
            if (hit.collider == null) continue;
            if (hit.collider.transform == player || hit.collider.transform.IsChildOf(player)) continue;
            if (hit.normal.y > 0.25f) return true;
        }
        return false;
    }

    void SetupPhysicsMaterials()
    {
        // Prefer the actual project assets created by the editor helper; fall back safely if missing.
        ballPhysicsMaterial = Resources.Load<PhysicMaterial>("BallPhysics");
        platformPhysicsMaterial = Resources.Load<PhysicMaterial>("PlatformPhysics");
        if (ballPhysicsMaterial == null)
        {
            ballPhysicsMaterial = new PhysicMaterial("Ball - Grippy Physics");
            ballPhysicsMaterial.dynamicFriction = 0.42f;
            ballPhysicsMaterial.staticFriction = 0.55f;
            ballPhysicsMaterial.bounciness = 0.08f;
            ballPhysicsMaterial.frictionCombine = PhysicMaterialCombine.Average;
            ballPhysicsMaterial.bounceCombine = PhysicMaterialCombine.Minimum;
        }
        if (platformPhysicsMaterial == null)
        {
            platformPhysicsMaterial = new PhysicMaterial("Platform - Stable Physics");
            platformPhysicsMaterial.dynamicFriction = 0.68f;
            platformPhysicsMaterial.staticFriction = 0.78f;
            platformPhysicsMaterial.bounciness = 0.02f;
            platformPhysicsMaterial.frictionCombine = PhysicMaterialCombine.Maximum;
            platformPhysicsMaterial.bounceCombine = PhysicMaterialCombine.Minimum;
        }
    }


    void MakeMaterials()
    {
        blue = MakeMaterial(new Color(0.07f, 0.25f, 0.48f), 0.2f);
        blueLight = MakeMaterial(new Color(0.12f, 0.48f, 0.78f), 0.25f);
        purple = MakeMaterial(new Color(0.32f, 0.12f, 0.62f), 0.2f);
        red = MakeMaterial(new Color(0.9f, 0.055f, 0.13f), 0.15f);
        gold = MakeMaterial(new Color(1f, 0.72f, 0.04f), 0.65f);
        cyan = MakeMaterial(new Color(0.05f, 0.9f, 1f), 0.45f);
        dark = MakeMaterial(new Color(0.018f, 0.04f, 0.085f), 0.1f);
        white = MakeMaterial(new Color(0.92f, 0.97f, 1f), 0.15f);
        green = MakeMaterial(new Color(0.05f, 0.58f, 0.35f), 0.15f);
        orange = MakeMaterial(new Color(1f, 0.34f, 0.04f), 0.25f);
    }

    Material MakeMaterial(Color color, float metallic)
    {
        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
        Material material = new Material(shader);
        material.color = color;
        if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
        if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 0.48f);
        return material;
    }

    void SetupCameraAndLight()
    {
        GameObject camObject = GameObject.Find("Main Camera");
        if (camObject == null) camObject = new GameObject("Main Camera");
        gameCamera = camObject.GetComponent<Camera>();
        if (gameCamera == null) gameCamera = camObject.AddComponent<Camera>();
        camObject.tag = "MainCamera";
        gameCamera.fieldOfView = 58f;
        if (camObject.GetComponent<AudioListener>() == null) camObject.AddComponent<AudioListener>();
        gameCamera.backgroundColor = new Color(0.28f, 0.62f, 0.9f);
        gameCamera.clearFlags = CameraClearFlags.Skybox;
        GameObject lightObject = GameObject.Find("Directional Light");
        if (lightObject == null) lightObject = new GameObject("Directional Light");
        Light light = lightObject.GetComponent<Light>();
        if (light == null) light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.25f;
        lightObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
        RenderSettings.ambientLight = new Color(0.52f, 0.58f, 0.68f);
    }

    void SetupMusic()
    {
        GameObject audioObject = new GameObject("Background Music");
        audioObject.transform.SetParent(transform);
        musicSource = audioObject.AddComponent<AudioSource>();
        musicSource.clip = CreateAmbientMusic();
        musicSource.loop = true;
        musicSource.playOnAwake = false;
        musicSource.volume = musicVolume;
        musicSource.spatialBlend = 0f;
        musicSource.ignoreListenerPause = true;
        musicSource.Play();

        GameObject sfxObject = new GameObject("Game Sound Effects");
        sfxObject.transform.SetParent(transform);
        sfxSource = sfxObject.AddComponent<AudioSource>();
        sfxSource.playOnAwake = false;
        sfxSource.spatialBlend = 0f;
        jumpClip = CreateTone("Jump", 520f, 0.16f, 0.22f);
        coinClip = CreateTone("Coin", 880f, 0.22f, 0.24f);
        hitClip = CreateTone("Hazard", 150f, 0.28f, 0.25f);
        winClip = CreateTone("Win", 660f, 0.55f, 0.22f);
        failClip = CreateTone("Fall", 190f, 0.45f, 0.24f);
    }

    void PlaySound(AudioClip clip)
    {
        if (soundEnabled && sfxSource != null && clip != null) sfxSource.PlayOneShot(clip);
    }

    AudioClip CreateTone(string clipName, float frequency, float duration, float amplitude)
    {
        const int sampleRate = 22050;
        int count = Mathf.Max(1, Mathf.RoundToInt(sampleRate * duration));
        float[] samples = new float[count];
        for (int i = 0; i < count; i++)
        {
            float t = (float)i / sampleRate;
            float fade = Mathf.Pow(1f - (float)i / count, 1.7f);
            float sweep = frequency * (1f + 0.18f * (1f - (float)i / count));
            samples[i] = (Mathf.Sin(2f * Mathf.PI * sweep * t) * 0.75f + Mathf.Sin(2f * Mathf.PI * sweep * 2f * t) * 0.18f) * amplitude * fade;
        }
        AudioClip clip = AudioClip.Create(clipName, count, 1, sampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }

    AudioClip CreateAmbientMusic()
    {
        // A soft, looping multi-note arpeggio generated in code; no external audio asset needed.
        const int sampleRate = 22050;
        const int seconds = 8;
        int count = sampleRate * seconds;
        float[] samples = new float[count];
        float[] melody = { 261.63f, 329.63f, 392.00f, 493.88f, 392.00f, 329.63f, 293.66f, 349.23f,
                           440.00f, 523.25f, 440.00f, 349.23f, 261.63f, 329.63f, 392.00f, 329.63f };
        for (int i = 0; i < count; i++)
        {
            float t = (float)i / sampleRate;
            int step = (int)(t * 2f) % melody.Length;
            float beat = t % 0.5f;
            float env = Mathf.Min(1f, beat * 18f) * Mathf.Min(1f, (0.5f - beat) * 8f);
            float note = melody[step];
            float pad = Mathf.Sin(2f * Mathf.PI * (note * 0.5f) * t) * 0.028f;
            float pluck = Mathf.Sin(2f * Mathf.PI * note * t) * 0.045f + Mathf.Sin(2f * Mathf.PI * note * 2f * t) * 0.012f;
            samples[i] = (pluck * env * 1.7f + pad * 1.3f);
        }
        AudioClip clip = AudioClip.Create("BouncyBall_MelodyLoop", count, 1, sampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }

    public void BuildLevel(bool preview)
    {
        if (levelRoot != null) Destroy(levelRoot.gameObject);
        GameObject rootObject = new GameObject("Bouncy Ball - Long Track");
        levelRoot = rootObject.transform;
        score = 0;
        coinTotal = 0;

        // One long level; difficulty changes track width, gap size, hazards and ball handling.
        float width = difficulty == 0 ? 9.2f : (difficulty == 1 ? 8.0f : 6.6f);
        int segments = 18;
        // Deliberately distinct gaps so the selected difficulty is immediately noticeable.
        float gap = difficulty == 0 ? 0.12f : (difficulty == 1 ? 1.05f : 1.85f);
        moveSpeed = difficulty == 0 ? 7.2f : (difficulty == 1 ? 7.8f : 8.35f);
        jumpForce = difficulty == 0 ? 8.8f : (difficulty == 1 ? 8.5f : 8.2f);
        cameraDistance = 9f;
        spawnPoint = new Vector3(0f, 0.82f, 0f);
        float z = 0f;
        for (int i = 0; i < segments; i++)
        {
            float length = i == 0 ? 12f : 8.2f;
            if (i > 0) z += gap;
            float sideWave = difficulty == 0 ? 0.18f : (difficulty == 1 ? 0.48f : 0.82f);
            float xOffset = Mathf.Sin(i * 0.67f) * sideWave;
            Material deck = i % 2 == 0 ? blueLight : blue;
            CreateCube("Platform " + (i + 1), new Vector3(xOffset, 0f, z + length * 0.5f), new Vector3(width, 0.75f, length), deck, rootObject.transform, true);

            // Tall continuous-looking rails help keep the ball on the track.
            float railHeight = difficulty == 0 ? 1.2f : (difficulty == 1 ? 1.05f : 0.88f);
            float railX = width * 0.5f - 0.12f;
            CreateCube("Left Safety Rail", new Vector3(xOffset - railX, 0.78f, z + length * 0.5f), new Vector3(0.24f, railHeight, length + gap), red, rootObject.transform, true);
            CreateCube("Right Safety Rail", new Vector3(xOffset + railX, 0.78f, z + length * 0.5f), new Vector3(0.24f, railHeight, length + gap), red, rootObject.transform, true);

            bool addHazard = difficulty == 0 ? (i > 2 && i % 5 == 0) : (difficulty == 1 ? (i > 1 && i % 3 == 0) : (i > 1 && i % 2 == 0));
            if (addHazard)
            {
                GameObject hazard = CreateCube("Rotating Coral Hazard", new Vector3(xOffset, 0.92f, z + length * 0.55f), new Vector3(width * (difficulty == 2 ? 0.76f : 0.60f), 0.28f, 0.42f), orange, rootObject.transform, true);
                hazard.AddComponent<RotatingHazard>().speed = difficulty == 0 ? 32f : (difficulty == 1 ? 58f : 88f);
            }

            int coins = 2;
            for (int c = 0; c < coins; c++)
            {
                float coinZ = z + 2.0f + (length - 4.0f) * c / Mathf.Max(1, coins - 1);
                float coinX = xOffset + (c == 0 ? -width * 0.18f : width * 0.18f);
                CreateCoin(new Vector3(coinX, 1.22f, coinZ), rootObject.transform);
                coinTotal++;
            }
            z += length;
        }
        finishZ = z + gap;
        CreateCube("Finish Platform", new Vector3(0f, 0f, finishZ + 3.4f), new Vector3(width + 1.5f, 0.75f, 7f), green, rootObject.transform, true);
        CreateCube("Finish Gate Left", new Vector3(-2.05f, 2f, finishZ + 3f), new Vector3(0.24f, 4f, 0.24f), cyan, rootObject.transform, false);
        CreateCube("Finish Gate Right", new Vector3(2.05f, 2f, finishZ + 3f), new Vector3(0.24f, 4f, 0.24f), cyan, rootObject.transform, false);
        CreateCube("Finish Gate Top", new Vector3(0f, 3.95f, finishZ + 3f), new Vector3(4.3f, 0.24f, 0.24f), cyan, rootObject.transform, false);
        GameObject finish = GameObject.CreatePrimitive(PrimitiveType.Cube);
        finish.name = "Finish Trigger";
        finish.transform.SetParent(rootObject.transform);
        finish.transform.position = new Vector3(0f, 1.5f, finishZ + 3f);
        finish.transform.localScale = new Vector3(width + 1f, 3f, 1f);
        finish.GetComponent<Renderer>().enabled = false;
        finish.GetComponent<Collider>().isTrigger = true;
        finish.AddComponent<FinishZone>();

        GameObject ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ball.name = "PlayerBall";
        ball.tag = "Player";
        ball.transform.SetParent(rootObject.transform);
        ball.transform.position = spawnPoint;
        ball.transform.localScale = Vector3.one * 0.82f;
        ball.GetComponent<Renderer>().material = cyan;
        SphereCollider ballCollider = ball.GetComponent<SphereCollider>();
        ballCollider.material = ballPhysicsMaterial;
        Rigidbody rb = ball.AddComponent<Rigidbody>();
        rb.mass = 0.85f;
        rb.linearDamping = 0.18f;
        rb.angularDamping = 0.08f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        player = ball.transform;
        playerBody = rb;
        if (preview) playerBody.isKinematic = true;
        gameCamera.transform.position = player.position + new Vector3(0f, 6.2f, -cameraDistance);
        gameCamera.transform.LookAt(player.position + Vector3.up * 0.5f);
    }

    GameObject CreateCube(string name, Vector3 position, Vector3 scale, Material material, Transform parent, bool collider)
    {
        GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        obj.name = name;
        obj.transform.SetParent(parent);
        obj.transform.position = position;
        obj.transform.localScale = scale;
        obj.GetComponent<Renderer>().material = material;
        Collider createdCollider = obj.GetComponent<Collider>();
        if (!collider) { if (createdCollider != null) Destroy(createdCollider); }
        else if (createdCollider != null && platformPhysicsMaterial != null) createdCollider.material = platformPhysicsMaterial;
        return obj;
    }

    void CreateCoin(Vector3 position, Transform parent)
    {
        GameObject coin = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        coin.name = "Collectible Coin";
        coin.transform.SetParent(parent);
        coin.transform.position = position;
        coin.transform.localScale = Vector3.one * 0.46f;
        coin.GetComponent<Renderer>().material = gold;
        SphereCollider collider = coin.GetComponent<SphereCollider>();
        collider.isTrigger = true;
        Rigidbody body = coin.AddComponent<Rigidbody>();
        body.isKinematic = true;
        body.useGravity = false;
        coin.AddComponent<CollectibleCoin>();
    }

    public void StartGame() { BuildLevel(false); State = GameState.Playing; }
    public void RestartLevel() { StartGame(); }
    public void CollectCoin() { score++; PlaySound(coinClip); }
    public void FinishLevel() { if (State == GameState.Playing) { State = GameState.Won; PlaySound(winClip); } }
    public void FailLevel() { if (State == GameState.Playing) { State = GameState.Failed; PlaySound(failClip); } }
    public void PlayHazardSound() { PlaySound(hitClip); }
    public void MainMenu() { BuildLevel(true); State = GameState.Menu; }

    void OnGUI()
    {
        InitStyles();
        if (State == GameState.Playing)
        {
            GUI.Box(new Rect(18, 18, 300, 92), GUIContent.none, panelStyle);
            GUI.Label(new Rect(34, 25, 270, 30), "LONG TRACK  •  " + new[] { "EASY", "NORMAL", "HARD" }[difficulty], hudStyle);
            GUI.Label(new Rect(34, 59, 270, 28), "GOLD ORBS  " + score + " / " + coinTotal, hudStyle);
            if (GUI.Button(new Rect(Screen.width - 152, 18, 134, 44), "Ⅱ  PAUSE", buttonStyle)) State = GameState.Paused;
            GUI.Label(new Rect(20, Screen.height - 42, 550, 30), (useArrowKeys ? "ARROWS" : "WASD") + "  MOVE     SPACE  JUMP     ESC  PAUSE", smallStyle);
            return;
        }
        float panelW = Mathf.Min(700f, Screen.width - 28f);
        float panelH = Mathf.Min(640f, Screen.height - 28f);
        float px = (Screen.width - panelW) * 0.5f;
        float py = (Screen.height - panelH) * 0.5f;
        GUI.Box(new Rect(px, py, panelW, panelH), GUIContent.none, panelStyle);
        float cx = Screen.width * 0.5f;
        if (State == GameState.Menu)
        {
            GUI.Label(new Rect(cx - 290, py + 22, 580, 60), "BOUNCY BALL CHALLENGE", titleStyle);
            GUI.Label(new Rect(cx - 290, py + 82, 580, 32), "ONE LONG 3D TRACK  •  COLLECT  •  JUMP  •  SURVIVE", subtitleStyle);
            GUI.Label(new Rect(cx - 280, py + 150, 560, 30), "CHOOSE YOUR DIFFICULTY", hudStyle);
            string[] difficulties = { "EASY", "NORMAL", "HARD" };
            for (int i = 0; i < 3; i++)
            {
                int chosen = i;
                if (GUI.Button(new Rect(cx - 280 + i * 190, py + 190, 178, 58), (difficulty == chosen ? "✓  " : "") + difficulties[i], buttonStyle))
            {
                difficulty = chosen;
                BuildLevel(true); // Rebuild the visible track immediately when difficulty changes.
            }
            }
            string diffInfo = difficulty == 0 ? "EASY • wide track • tiny gaps • fewer hazards" : (difficulty == 1 ? "NORMAL • balanced track • medium gaps • regular hazards" : "HARD • narrow track • large gaps • more, faster hazards");
            GUI.Label(new Rect(cx - 290, py + 258, 580, 40), diffInfo, smallStyle);
            if (GUI.Button(new Rect(cx - 220, py + 315, 440, 58), "▶   START GAME", buttonStyle)) StartGame();
            if (GUI.Button(new Rect(cx - 220, py + 382, 440, 48), "SETTINGS  ⚙", buttonStyle)) State = GameState.Settings;
            GUI.Label(new Rect(cx - 290, py + 448, 580, 48), "Dodge red hazards, collect gold coins and reach the cyan finish gate.", smallStyle);
            GUI.Label(new Rect(cx - 290, py + 500, 580, 30), "Controls and music volume can be changed in Settings.", smallStyle);
        }
        else if (State == GameState.Settings)
        {
            GUI.Label(new Rect(cx - 280, py + 34, 560, 58), "SETTINGS", titleStyle);
            GUI.Label(new Rect(cx - 250, py + 126, 500, 30), "MOVEMENT CONTROLS", hudStyle);
            if (GUI.Button(new Rect(cx - 245, py + 165, 230, 54), (useArrowKeys ? "" : "✓  ") + "W A S D", buttonStyle)) useArrowKeys = false;
            if (GUI.Button(new Rect(cx + 15, py + 165, 230, 54), (useArrowKeys ? "✓  " : "") + "ARROW KEYS", buttonStyle)) useArrowKeys = true;
            GUI.Label(new Rect(cx - 250, py + 247, 500, 30), "BACKGROUND MUSIC & SOUND EFFECTS", hudStyle);
            soundEnabled = GUI.Toggle(new Rect(cx - 245, py + 286, 120, 35), soundEnabled, "Sound On");
            GUI.Label(new Rect(cx - 90, py + 286, 95, 35), "Music", smallStyle);
            musicVolume = GUI.HorizontalSlider(new Rect(cx + 5, py + 294, 230, 25), musicVolume, 0f, 0.6f);
            GUI.Label(new Rect(cx - 250, py + 345, 500, 40), "JUMP: SPACE      PAUSE: ESC  •  SFX ON/OFF WITH SOUND", subtitleStyle);
            if (GUI.Button(new Rect(cx - 180, py + 414, 360, 54), "BACK TO MENU", buttonStyle)) State = GameState.Menu;
        }
        else if (State == GameState.Paused)
        {
            GUI.Label(new Rect(cx - 280, py + 50, 560, 60), "PAUSED", titleStyle);
            if (GUI.Button(new Rect(cx - 190, py + 155, 380, 52), "RESUME", buttonStyle)) State = GameState.Playing;
            if (GUI.Button(new Rect(cx - 190, py + 220, 380, 52), "RESTART LEVEL", buttonStyle)) RestartLevel();
            if (GUI.Button(new Rect(cx - 190, py + 285, 380, 52), "SETTINGS", buttonStyle)) State = GameState.Settings;
            if (GUI.Button(new Rect(cx - 190, py + 350, 380, 52), "MAIN MENU", buttonStyle)) MainMenu();
        }
        else
        {
            bool won = State == GameState.Won;
            GUI.Label(new Rect(cx - 280, py + 65, 560, 65), won ? "LEVEL COMPLETE!" : "TRY AGAIN", titleStyle);
            GUI.Label(new Rect(cx - 280, py + 140, 560, 35), "Gold orbs: " + score + " / " + coinTotal, subtitleStyle);
            if (GUI.Button(new Rect(cx - 190, py + 240, 380, 52), won ? "PLAY AGAIN" : "RETRY TRACK", buttonStyle)) RestartLevel();
            if (GUI.Button(new Rect(cx - 190, py + 305, 380, 52), "MAIN MENU", buttonStyle)) MainMenu();
        }
    }

    void InitStyles()
    {
        if (stylesReady) return;
        titleStyle = new GUIStyle(GUI.skin.label); titleStyle.fontSize = 34; titleStyle.fontStyle = FontStyle.Bold; titleStyle.alignment = TextAnchor.MiddleCenter; titleStyle.normal.textColor = new Color(0.15f, 0.95f, 1f);
        subtitleStyle = new GUIStyle(GUI.skin.label); subtitleStyle.fontSize = 17; subtitleStyle.alignment = TextAnchor.MiddleCenter; subtitleStyle.normal.textColor = Color.white;
        buttonStyle = new GUIStyle(GUI.skin.button); buttonStyle.fontSize = 16; buttonStyle.fontStyle = FontStyle.Bold; buttonStyle.wordWrap = true; buttonStyle.normal.textColor = Color.white;
        hudStyle = new GUIStyle(GUI.skin.label); hudStyle.fontSize = 18; hudStyle.fontStyle = FontStyle.Bold; hudStyle.normal.textColor = Color.white;
        smallStyle = new GUIStyle(GUI.skin.label); smallStyle.fontSize = 14; smallStyle.alignment = TextAnchor.MiddleCenter; smallStyle.wordWrap = true; smallStyle.normal.textColor = Color.white;
        panelStyle = new GUIStyle(GUI.skin.box); panelStyle.normal.background = MakePanelTexture();
        stylesReady = true;
    }
    Texture2D MakePanelTexture()
    {
        Texture2D tex = new Texture2D(1, 1); tex.SetPixel(0, 0, new Color(0.025f, 0.075f, 0.14f, 0.93f)); tex.Apply(); return tex;
    }
}
